const sizeProfiles = Object.freeze({
  tiny: Object.freeze({ spaceFeet: 2.5, carryingMultiplier: 0.5 }),
  small: Object.freeze({ spaceFeet: 5, carryingMultiplier: 1 }),
  medium: Object.freeze({ spaceFeet: 5, carryingMultiplier: 1 }),
  large: Object.freeze({ spaceFeet: 10, carryingMultiplier: 2 }),
  huge: Object.freeze({ spaceFeet: 15, carryingMultiplier: 4 }),
  gargantuan: Object.freeze({ spaceFeet: 20, carryingMultiplier: 8 }),
});
const creatureSizes = Object.freeze(Object.keys(sizeProfiles));

function sizeProfile(size) {
  return Object.hasOwn(sizeProfiles, size) ? sizeProfiles[size] : undefined;
}

function sizeWithinMaximum(size, referenceSize, allowance = 0) {
  const rank = creatureSizes.indexOf(size);
  const referenceRank = creatureSizes.indexOf(referenceSize);
  return rank >= 0 && referenceRank >= 0 && rank <= referenceRank + allowance;
}

function oneSizeLarger(size, cap) {
  const rank = creatureSizes.indexOf(size);
  const capRank = creatureSizes.indexOf(cap);
  if (rank < 0 || capRank < 0 || rank >= capRank) return size;
  return creatureSizes[rank + 1];
}

module.exports = { creatureSizes, sizeProfile, sizeWithinMaximum, oneSizeLarger };
